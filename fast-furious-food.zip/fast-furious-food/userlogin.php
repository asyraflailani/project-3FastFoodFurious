<!DOCTYPE HTML> 
<html>
<head>
</head>
<body> 
<h4>
<text style="margin-left: 180px">Fill Details</text> 
<hr>
</h4>

<form method="post" action="usercheck.php"> 
<table style="margin-left:80px" >
<tr><td>User Name: </td><td><input type="text" name="un" required>
   <br><br></td></tr>
   <tr><td>Password:</td><td> <input type="password" name="pwd" required>
   <br><br></td></tr>
   
   <tr><td></td><td><input type="submit" name="submit" value="Submit"> </td></tr>
   </table>
</form>
</body>
</html>