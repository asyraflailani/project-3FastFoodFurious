<!DOCTYPE HTML> 
<html>
<head>
</head>
<body> 

<h2 align="center"><font color="green">Search all orders by Order Id</font> </h2>
<form method="post" action="searchbyid.php" > 
   Enter Your Order Id:  <input type="number" name="id" required>
   <br><br>

 <h2 align="center"> <input type="submit" name="submit" value="Search" align="center">  </h2>
</form>



</body>
</html>