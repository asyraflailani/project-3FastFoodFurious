<!DOCTYPE HTML> 
<html>
<head>
</head>
<body> 
<h4>
<text style="margin-left: 200px">Fill Details</text> 
<hr>
</h4>

<form method="post" action="insertDB.php"> 
<table style="margin-left:50px" >
   <tr><td>Food:</td><td> <select name = "od">
 <option value="Saltegg">Salted Egg Butter Chicken(RM12)</option>
 <option value="Kam">Kam Heong Chicken(RM12)</option>
 <option value="Black pepper">Black Pepper Chicken Chop Rice(RM12)</option>
 <option value="SweetSour">Sweet & Sour Chicken(RM12)</option>
 <option value="Honey Soy">Honey Soy Sesame Chicken(RM9)</option>
 <option value="Chili Chicken">Chili Chicken(RM9)</option>
 <option value="Garlic Black">Garlic Black Pepper Chicken(RM12)</option>
 </select><br><br></td></tr>

<form method="post" action="insertDB.php"> 
<table style="margin-left:50px" >
   <tr><td>Drink:</td><td> <select name = "dr">
 <option value="TehO">Teh O Ais(RM2)</option>
 <option value="Crysa">Chrysanthemum(RM6)</option>
 <option value="TehA">Teh Ais(RM4)</option>
 <option value="Limau">Limau Ais(RM3)</option>
 <option value="Barli">Barli Ais(RM5)</option>
 <option value="Bandung">Sirap Bandung Ais(RM5)</option>
 <option value="Barli Limau">Barli Limau Ais(RM5)</option>
 </select><br><br></td></tr>
 
   <tr><td>Quantity of Food:</td><td><input type="number" maxlength="2" name="pa" min="1" max="10" required > 
   <br><br></td></tr>
   <tr><td>Quantity of Drink:</td><td><input type="number" maxlength="2" name="pi" min="1" max="10" required > 
   <br><br></td></tr>
   <tr><td>Email:</td><td> <input type="email" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required>
   <br><br></td></tr>
   <tr><td>Mobile Number(+60):</td><td> <input type="number" name="cm" maxlength="10"  required>
   <br><br></td></tr>
   <tr><td>Current Address:</td><td><textarea rows="4" cols="25" name="ca" required></textarea>
   <br><br></td></tr>
   <tr><td></td><td><input type="submit" name="submit" value="Submit" > </td></tr>
   </table>
</form>

</body>
</html>