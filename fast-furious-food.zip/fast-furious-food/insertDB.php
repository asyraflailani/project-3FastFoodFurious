<?php
// define variables and set to empty values
$od = $dr = $pa = $pi  = $ca = $cm = $dbpn = $dbn = $price = $prices = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   $od = test_input($_POST["od"]);
   $dr = test_input($_POST["dr"]);
   $pa = test_input($_POST["pa"]);
   $pi = test_input($_POST["pi"]);
   $ca = test_input($_POST["ca"]);
   $cm = test_input($_POST["cm"]);
   if($od=="Saltegg")
   { 
        $price = 12*$pa;
		}
	else if($od=="Kam")
   { 
        $price = 12*$pa;
		}
	else if($od=="Black pepper")
   { 
        $price = 12*$pa;
        }
    else if($od=="SweetSour")
   { 
        $price = 12*$pa;
        }
     else if($od=="Honey Soy")
    { 
        $price = 9*$pa;
        }
     else if($od=="Chili Chicken")
   { 
        $price = 9*$pa;
        }
    else if($od=="Garlic Black")
    { 
        $price = 12*$pa;
        }


	if($dr=="TehO")
   { 
        $prices = 2*$pi;
		}
	else if($dr=="Crysa")
   { 
        $prices = 6*$pi;
		}
	else if($dr=="TehA")
   { 
        $prices = 4*$pi;
        }
     else if($dr=="Limau")
   { 
        $prices = 3*$pi;
        }
     else if($dr=="Barli")
    { 
        $prices = 5*$pi;
        }
     else if($dr=="Bandung")
   { 
        $prices = 5*$pi;
        }
    else if($dr=="Barli Limau")
    { 
        $prices = 5*$pi;
        }
		
        echo "<br>You order is successful. <br>";
        echo "<br>Please Wait for delivery boy to send your order. <br>";
        echo "You have to pay RM" .$price. " for your food.<br>";
        echo "You have to pay RM" .$prices. " for your drink.<br>";
        
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>


<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mydbb2";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO phptable2 (OrderDetailsFood, OrderDetailsDrink, PaymentAmountFood, PaymentAmountDrink, CustomerAddress, CustomerMobile)
VALUES ('$od', '$dr', '$price', '$prices', '$ca', '$cm')";

if ($conn->query($sql) === TRUE) {
    
	echo "Your order id is: ";
	$sql = "SELECT orderid FROM phptable2 WHERE  CustomerMobile='" . $cm . "'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
	
    {
	while($row = $result->fetch_assoc()) {
        echo $row["orderid"];
		
    }
    }
}
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>